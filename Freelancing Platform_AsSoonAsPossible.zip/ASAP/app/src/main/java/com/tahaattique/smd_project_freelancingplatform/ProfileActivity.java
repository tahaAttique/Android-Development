package com.tahaattique.smd_project_freelancingplatform;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.RatingBar;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import de.hdodenhof.circleimageview.CircleImageView;

public class ProfileActivity extends AppCompatActivity {

    String username,phoneNo,email1,url;
    TextView name;
    TextView phone,email,desc;
    CircleImageView img;
    FirebaseUser firebaseUser;
    DatabaseReference reference;
    Button btn_link;
    RatingBar ratingBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        name=findViewById(R.id.name);
        phone=findViewById(R.id.phone);
        btn_link=findViewById(R.id.openlink);
        email=findViewById(R.id.email);
        desc=findViewById(R.id.desc);
        img=findViewById(R.id.img);
        ratingBar = (RatingBar) findViewById(R.id.ratingBar);

        Intent intent=getIntent();
        username=intent.getStringExtra("name");
        name.setText(username);


        firebaseUser= FirebaseAuth.getInstance().getCurrentUser();
        reference= FirebaseDatabase.getInstance().getReference("users").child(firebaseUser.getUid());

        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                User user =dataSnapshot.getValue(User.class);
                phone.setText(user.getPhone());
                email.setText(user.getEmail());
                desc.setText(user.getDesc());
                url=user.getPortfolio();
                String sr=user.getRating();
                Float r=Float.valueOf(user.getRating());
                ratingBar.setRating(r);
                ratingBar.setIsIndicator(true);
                String encodedImage=user.getImage();

                byte[] decodedString = Base64.decode(encodedImage, Base64.DEFAULT);
                Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);

                img.setImageBitmap(decodedByte);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        btn_link.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!url.startsWith("https://") && !url.startsWith("http://")){
                    url = "http://" + url;
                }
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(url));
                startActivity(i);
            }
        });

    }
}
