package com.tahaattique.smd_project_freelancingplatform;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.tahaattique.smd_project_freelancingplatform.Adapter.Client_PresentProjects_Adaptor;
import com.tahaattique.smd_project_freelancingplatform.Adapter.FreelancerBidderAdapter;

import java.util.ArrayList;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class FreelancerAddProj extends AppCompatActivity {

    Spinner categorySpinner;
    String selectedCategory;

    CircleImageView profile_image;
    TextView username;

    private RecyclerView RV_presentProjects;
    private FreelancerBidderAdapter ClientAdapter;
    private List<Project> mProjects;
    private String PresentClientID;



    FirebaseUser firebaseUser;
    DatabaseReference reference;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_freelancer_add_proj);

        categorySpinner = findViewById(R.id.categorySpinner);
        selectedCategory="";
        this.categorySipper_run();

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        profile_image=findViewById(R.id.profile_image);
        username=findViewById(R.id.username);
        profile_image=findViewById(R.id.profile_image);

        RV_presentProjects=findViewById(R.id.RV_presentProjects);
        RV_presentProjects.setHasFixedSize(true);
        RV_presentProjects.setLayoutManager(new LinearLayoutManager(FreelancerAddProj.this));
        mProjects=new ArrayList<>();

        //readPlayers("ALL");


        firebaseUser= FirebaseAuth.getInstance().getCurrentUser();
        reference= FirebaseDatabase.getInstance().getReference("users").child(firebaseUser.getUid());

        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                User user =dataSnapshot.getValue(User.class);
                username.setText(user.getUsername());
                PresentClientID=user.getId();

                //if(user.getImageURL().equals("default"))
                {
                    //profile_image.setImageResource(R.mipmap.ic_launcher);
                }
                //else
                {
                    // Glide.with(MainActivity.this).load(user.getImageURL()).into(profile_image);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }

    private void readPlayers(final String val) {

        final FirebaseUser firebaseUser= FirebaseAuth.getInstance().getCurrentUser();
        DatabaseReference reference=FirebaseDatabase.getInstance().getReference("Projects");

        reference.addValueEventListener(new ValueEventListener()
        {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                mProjects.clear();
                for (DataSnapshot snapshot: dataSnapshot.getChildren())
                {
                    Project project=snapshot.getValue(Project.class);
                    if(val.equals("All"))
                    {
                        if(project.getStatus().equals("NOT_ASSIGNED"))
                        {
                            mProjects.add(project);
                        }
                    }
                    else
                    {
                        if(project.getCategory().equals(val))
                        {
                            if(project.getStatus().equals("NOT_ASSIGNED"))
                            {
                                mProjects.add(project);
                            }
                        }
                    }


                }

                ClientAdapter =new FreelancerBidderAdapter(FreelancerAddProj.this,mProjects);
                RV_presentProjects.setAdapter(ClientAdapter);

                if(mProjects.size()==0)
                {
                    Toast.makeText(getApplicationContext(),"No Projects Found",Toast.LENGTH_SHORT).show();
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        getMenuInflater().inflate(R.menu.menu,menu);
        return true;
    }


    public boolean onOptionsItemSelected(MenuItem item)
    {
        switch (item.getItemId())
        {
            case R.id.logout:
                FirebaseAuth.getInstance().signOut();
                startActivity(new Intent(FreelancerAddProj.this, LoginActivity.class));
                finish();
                return true;
        }

        return false;
    }

    public void categorySipper_run ()
    {

        ArrayAdapter<String> categoryAdapter = new ArrayAdapter<String>(FreelancerAddProj.this,
                android.R.layout.simple_list_item_1, getResources().getStringArray(R.array.categories1));
        categoryAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        categorySpinner.setAdapter(categoryAdapter);
        categorySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {

                if (adapterView.getItemAtPosition(position).equals("Choose Category")) {
                    selectedCategory="";
                } else {
                    //on selecting a spinner item
                    selectedCategory = adapterView.getItemAtPosition(position).toString();
                    readPlayers(selectedCategory);
                    //Toast.makeText(AddProjectActivity.this, item, Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

    }

}
