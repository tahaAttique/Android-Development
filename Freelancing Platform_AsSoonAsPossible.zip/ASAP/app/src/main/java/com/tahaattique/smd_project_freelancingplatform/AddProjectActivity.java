package com.tahaattique.smd_project_freelancingplatform;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageException;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.rengwuxian.materialedittext.MaterialEditText;

import java.util.Date;
import java.util.HashMap;

public class AddProjectActivity extends AppCompatActivity {

    Uri fileUri; //uri are actually URL that are meant for local storage
    ProgressDialog progressDialog;

    Spinner categorySpinner;
    String selectedCategory;

    MaterialEditText Name,Description,Date,Reward;
    Button btn_add,btn_upload;
    TextView txt_selected,txt_uploaded;
    ImageButton btn_attach;
    String attachment;

    FirebaseAuth auth;
    FirebaseStorage  storage; // for upload
    DatabaseReference reference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_project);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Add Project");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        Name=findViewById(R.id.name);
        Description=findViewById(R.id.desc);
        Date=findViewById(R.id.date);
        Reward=findViewById(R.id.reward);
        btn_add=findViewById(R.id.btn_add);
        btn_attach=findViewById(R.id.btn_attach);
        btn_upload=findViewById(R.id.btn_upload);
        txt_selected=findViewById(R.id.txt_selected);
        txt_uploaded=findViewById(R.id.txt_uploaded);

        //firebase
        auth= FirebaseAuth.getInstance();
        storage=FirebaseStorage.getInstance(); // this will return obj for current firebase storage

        attachment="";

        // Category dropMenu or Spinner
        categorySpinner = findViewById(R.id.categorySpinner);
        selectedCategory="";
        this.categorySipper_run();


        btn_attach.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(ContextCompat.checkSelfPermission(AddProjectActivity.this,
                        Manifest.permission.READ_EXTERNAL_STORAGE)== PackageManager.PERMISSION_GRANTED) // check permission
                {
                    selectFile();
                }
                else
                {
                    ActivityCompat.requestPermissions(AddProjectActivity.this,new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},9);
                }
            }
        });




        btn_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String txt_name=Name.getText().toString();
                String txt_description=Description.getText().toString();
                String txt_date=Date.getText().toString();
                String txt_reward=Reward.getText().toString();

                if(TextUtils.isEmpty(txt_name)|| TextUtils.isEmpty(txt_description) || TextUtils.isEmpty(txt_date) || TextUtils.isEmpty(txt_reward) || selectedCategory.equals(""))
                {
                    Toast.makeText(AddProjectActivity.this, "All Fields are Required ", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    addProject( selectedCategory ,txt_name, txt_description, txt_date, txt_reward,attachment,"NOT_ASSIGNED");
                }
            }
        });


        btn_upload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (fileUri!=null) // the user has selected the file
                    uploadFile(fileUri);
                else
                    Toast.makeText(AddProjectActivity.this, "Select a File", Toast.LENGTH_SHORT).show();

            }
        });

    }

    private void uploadFile(Uri fileUri) {

        progressDialog=new ProgressDialog(this);
        progressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
        progressDialog.setTitle("Uploading FIle...");
        progressDialog.setProgress(0);
        progressDialog.show();


        String fileName =System.currentTimeMillis()+"";
        StorageReference storageReference =storage.getReference(); //returns root path
        storageReference.child("Uploads").child(fileName).putFile(fileUri)
        .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                 attachment=taskSnapshot.getMetadata().getReference().getDownloadUrl().toString(); //return the url of your uploaded file..
                txt_uploaded.setText("Uploaded " + " Downloaded link : " + attachment  );
                
        }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {

                Toast.makeText(AddProjectActivity.this, "File not successfully Uploaded ", Toast.LENGTH_SHORT).show();

            }
        }).addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {

                //Track the progress of our upload
                int currentProgress=(int) (100*taskSnapshot.getBytesTransferred()/taskSnapshot.getTotalByteCount());
                progressDialog.setProgress(currentProgress);

            }
        });

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if(requestCode==9 &&  grantResults[0]==PackageManager.PERMISSION_GRANTED) // we asked for just one permission so it is stored on grantResults[0]
            { selectFile();

        }
        else
        {
            Toast.makeText(this, "Please Provide Permission...", Toast.LENGTH_SHORT).show();
        }
    }

    private void selectFile()
    {
        // to offer user to select a file using file manager
        // we will use Intent for this
        Intent intent =new Intent();
        intent.setType("application/pdf");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(intent,86);
    }



    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {

        // check weather user has selected a file or not
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 86 && resultCode == RESULT_OK && data != null) // RESULT_OK -> SUCCESS
        {
            fileUri = data.getData(); // returns Uri of the selected file
            txt_selected.setText(fileUri.toString());
        } else {
            Toast.makeText(this, "Please Select a FIle", Toast.LENGTH_SHORT).show();
        }

    }

    public void addProject( String category , String name, String Desc, String requiredDate, String reward, String attachments,String status)
    {
        FirebaseUser firebaseUser=auth.getCurrentUser();
        String userid= firebaseUser.getUid();

        reference= FirebaseDatabase.getInstance().getReference();
        HashMap<String,Object> hashMap=new HashMap<>();
        hashMap.put("category",category);
        hashMap.put("name",name);
        hashMap.put("Desc",Desc);
        hashMap.put("requiredDate",requiredDate);
        hashMap.put("reward",reward);
        hashMap.put("freelancer","");
        hashMap.put("client",userid);
        hashMap.put("attachments",attachments);
        hashMap.put("status",status);


        reference.child("Projects").push().setValue(hashMap);
        finish();
    }




    public void categorySipper_run ()
    {

        ArrayAdapter<String> categoryAdapter = new ArrayAdapter<String>(AddProjectActivity.this,
                android.R.layout.simple_list_item_1, getResources().getStringArray(R.array.categories));
        categoryAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        categorySpinner.setAdapter(categoryAdapter);
        categorySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {

                if (adapterView.getItemAtPosition(position).equals("Choose Category")) {
                    selectedCategory="";
                } else {
                    //on selecting a spinner item
                    selectedCategory = adapterView.getItemAtPosition(position).toString();

                    //Toast.makeText(AddProjectActivity.this, item, Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

    }
}
