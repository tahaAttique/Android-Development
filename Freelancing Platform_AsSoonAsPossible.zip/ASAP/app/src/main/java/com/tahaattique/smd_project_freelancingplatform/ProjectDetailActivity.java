package com.tahaattique.smd_project_freelancingplatform;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class ProjectDetailActivity extends AppCompatActivity {

    Intent intent;
    TextView txt_name,txt_requiredDate,txt_reward,txt_desc;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_project_detail);

        intent=getIntent();
        String ProjectName=intent.getStringExtra("getName");

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Project Description");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        txt_name=findViewById(R.id.txt_name);
        txt_requiredDate=findViewById(R.id.txt_requiredDate);
        txt_reward=findViewById(R.id.txt_reward);
        txt_desc=findViewById(R.id.txt_desc);


        txt_name.setText(ProjectName.toUpperCase());
        txt_requiredDate.setText("Required Date : " + intent.getStringExtra("getRequiredDate"));
        txt_reward.setText("Reward : "+intent.getStringExtra("getReward"));
        txt_desc.setText(intent.getStringExtra("getDesc"));


    }
}
