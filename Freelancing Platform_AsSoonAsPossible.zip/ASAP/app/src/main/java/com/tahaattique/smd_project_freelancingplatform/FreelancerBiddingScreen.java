package com.tahaattique.smd_project_freelancingplatform;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.tahaattique.smd_project_freelancingplatform.Adapter.Client_PresentProjects_Adaptor;

import java.util.HashMap;

public class FreelancerBiddingScreen extends AppCompatActivity {

    Intent intent;
    TextView txt_name,txt_requiredDate,txt_reward,txt_desc;
    Button btn_apply;
    FirebaseAuth auth;
    DatabaseReference reference;
    String ProjectName;
    FirebaseUser firebaseUser;
    String Username;
    String UsernameID;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_freelancer_bidding_screen);

        intent = getIntent();
        ProjectName = intent.getStringExtra("getName");

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Project Description");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        auth= FirebaseAuth.getInstance();


        txt_name = findViewById(R.id.txt_name);
        txt_requiredDate = findViewById(R.id.txt_requiredDate);
        txt_reward = findViewById(R.id.txt_reward);
        txt_desc = findViewById(R.id.txt_desc);
        btn_apply=findViewById(R.id.apply);

        txt_name.setText(ProjectName.toUpperCase());
        txt_requiredDate.setText("Required Date : " + intent.getStringExtra("getRequiredDate"));
        txt_reward.setText("Reward : " + intent.getStringExtra("getReward"));
        txt_desc.setText(intent.getStringExtra("getDesc"));
        getName();

        btn_apply.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                bid();
            }
        });
    }

    public void bid( )
    {
        final FirebaseUser firebaseUser= FirebaseAuth.getInstance().getCurrentUser();
        DatabaseReference reference=FirebaseDatabase.getInstance().getReference("Projects");

        reference.addListenerForSingleValueEvent(new ValueEventListener()
        {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                for (DataSnapshot snapshot: dataSnapshot.getChildren())
                {
                    Project project=snapshot.getValue(Project.class);

                    if(project.getName().equals(ProjectName))
                    {
                       String tmp=project.getFreelancer();
                       tmp=tmp+"~";
                       tmp=tmp+Username;
                       project.setFreelancer(tmp);

                        String tmpID=project.getFreelancerID();
                        if (tmpID==null)
                        {
                            tmpID="";
                        }
                        tmpID=tmpID+"~";
                        tmpID=tmpID+UsernameID;
                        project.setFreelancerID(tmpID);
                        //snapshot.getRef().removeValue();
                        snapshot.getRef().setValue(project);

                        break;
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


        Toast.makeText(getApplicationContext(),"Your Application is Submitted", Toast.LENGTH_SHORT).show();
        finish();
    }

    public void getName()
    {
        firebaseUser= FirebaseAuth.getInstance().getCurrentUser();
        reference= FirebaseDatabase.getInstance().getReference("users").child(firebaseUser.getUid());

        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                User user =dataSnapshot.getValue(User.class);
                Username=user.getUsername();
                UsernameID=user.getId();

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }


}
