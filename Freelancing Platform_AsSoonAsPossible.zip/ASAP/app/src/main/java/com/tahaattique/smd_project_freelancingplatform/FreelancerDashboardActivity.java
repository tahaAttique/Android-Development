package com.tahaattique.smd_project_freelancingplatform;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.tahaattique.smd_project_freelancingplatform.Adapter.Client_PresentProjects_Adaptor;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class FreelancerDashboardActivity extends AppCompatActivity {

    Button btn_addProject,btn_chat,btn_profile,btn_assProj;
    TextView heading;

    //toolbar of user
    CircleImageView profile_image;
    TextView username;

    private RecyclerView RV_presentProjects;
    private Client_PresentProjects_Adaptor ClientAdapter;
    private List<Project> mProjects;
    private String PresentClientID;

    public String username1;
    public String phone,email,image;

    FirebaseUser firebaseUser;
    DatabaseReference reference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_freelancer_dashboard);


        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        profile_image=findViewById(R.id.profile_image);
        username=findViewById(R.id.username);
        profile_image=findViewById(R.id.profile_image);
        btn_addProject=findViewById(R.id.btn_newProject);
        btn_chat=findViewById(R.id.btn_chat);
        btn_profile=findViewById(R.id.btn_profile);
        btn_assProj=findViewById(R.id.btn_AssProject);
        heading=findViewById(R.id.heading);

        RV_presentProjects=findViewById(R.id.RV_presentProjects);
        RV_presentProjects.setHasFixedSize(true);
        RV_presentProjects.setLayoutManager(new LinearLayoutManager(FreelancerDashboardActivity.this));
        mProjects=new ArrayList<>();


        firebaseUser= FirebaseAuth.getInstance().getCurrentUser();
        reference= FirebaseDatabase.getInstance().getReference("users").child(firebaseUser.getUid());

        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                User user =dataSnapshot.getValue(User.class);
                username.setText(user.getUsername());
                username1=user.getUsername();
                PresentClientID=user.getId();
                phone=user.getPhone();
                email=user.getEmail();
                image=user.getImage();

                //if(user.getImageURL().equals("default"))
                {
                    //profile_image.setImageResource(R.mipmap.ic_launcher);
                }
                //else
                {
                    // Glide.with(MainActivity.this).load(user.getImageURL()).into(profile_image);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        readPlayers("ASSIGNED");
        btn_assProj.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                readPlayers("ASSIGNED");
                heading.setText("Assigned Projects");
            }
        });

        btn_addProject.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(FreelancerDashboardActivity.this,FreelancerAddProj.class);
                startActivity(intent);
            }
        });

        btn_profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(FreelancerDashboardActivity.this,ProfileActivity.class);
                intent.putExtra("name",username1);
                startActivity(intent);
            }
        });
        btn_chat.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                Intent intent = new Intent(FreelancerDashboardActivity.this,ChatActivity.class);
                startActivity(intent);
            }
        });
    }

    private void readPlayers(final String val) {

        final FirebaseUser firebaseUser= FirebaseAuth.getInstance().getCurrentUser();
        DatabaseReference reference=FirebaseDatabase.getInstance().getReference("Projects");

        reference.addValueEventListener(new ValueEventListener()
        {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                mProjects.clear();
                for (DataSnapshot snapshot: dataSnapshot.getChildren())
                {
                    Project project=snapshot.getValue(Project.class);

                    if(project.getFreelancer().equals(username1))
                    {
                        if(project.getStatus().equals(val))
                        {
                            mProjects.add(project);
                        }
                    }
                }

                ClientAdapter =new Client_PresentProjects_Adaptor(FreelancerDashboardActivity.this,mProjects);
                RV_presentProjects.setAdapter(ClientAdapter);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        getMenuInflater().inflate(R.menu.menu,menu);
        return true;
    }


    public boolean onOptionsItemSelected(MenuItem item)
    {
        switch (item.getItemId())
        {
            case R.id.logout:
                FirebaseAuth.getInstance().signOut();
                startActivity(new Intent(FreelancerDashboardActivity.this, LoginActivity.class));
                finish();
                return true;
        }

        return false;
    }
}
