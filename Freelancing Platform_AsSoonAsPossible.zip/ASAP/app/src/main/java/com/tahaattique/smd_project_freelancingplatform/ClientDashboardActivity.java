package com.tahaattique.smd_project_freelancingplatform;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.tahaattique.smd_project_freelancingplatform.Adapter.ClientBiddingAdapter;
import com.tahaattique.smd_project_freelancingplatform.Adapter.ClientFinishProjectAdapter;
import com.tahaattique.smd_project_freelancingplatform.Adapter.Client_PresentProjects_Adaptor;

import java.util.ArrayList;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class ClientDashboardActivity extends AppCompatActivity {

    Button btn_addProject,btn_bidded,btn_chat,btn_profile,btn_assProj;
    TextView heading;

    //toolbar of user
    CircleImageView profile_image;
    TextView username;

    private RecyclerView RV_presentProjects;
    private Client_PresentProjects_Adaptor ClientAdapter;
    private ClientBiddingAdapter BiddingAdapter;
    private ClientFinishProjectAdapter Adapter3;
    private List<Project> mProjects;
    private String PresentClientID;



    FirebaseUser firebaseUser;
    DatabaseReference reference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_client_dashboard);


        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        profile_image=findViewById(R.id.profile_image);
        username=findViewById(R.id.username);
        profile_image=findViewById(R.id.profile_image);
        btn_bidded=findViewById(R.id.btn_bidded);
        btn_addProject=findViewById(R.id.btn_addProject);
        btn_chat=findViewById(R.id.btn_chat);
        btn_profile=findViewById(R.id.btn_profile);
        btn_assProj=findViewById(R.id.btn_AssProject);
        heading=findViewById(R.id.heading);

        RV_presentProjects=findViewById(R.id.RV_presentProjects);
        RV_presentProjects.setHasFixedSize(true);
        RV_presentProjects.setLayoutManager(new LinearLayoutManager(ClientDashboardActivity.this));
        mProjects=new ArrayList<>();

        readPlayers("ASSIGNED");


        firebaseUser= FirebaseAuth.getInstance().getCurrentUser();
        reference= FirebaseDatabase.getInstance().getReference("users").child(firebaseUser.getUid());

        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                User user =dataSnapshot.getValue(User.class);
                username.setText(user.getUsername());
                PresentClientID=user.getId();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


        btn_assProj.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                readPlayers("ASSIGNED");
                heading.setText("Assigned Projects");
            }
        });

        btn_addProject.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ClientDashboardActivity.this,AddProjectActivity.class);
                startActivity(intent);
            }
        });

        btn_bidded.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                readPlayers("NOT_ASSIGNED");
                heading.setText("Bidded Projects");
            }
        });
        btn_chat.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ClientDashboardActivity.this,ChatActivity.class);
                startActivity(intent);
            }
        });


    }

    private void readPlayers(final String val) {

        final FirebaseUser firebaseUser= FirebaseAuth.getInstance().getCurrentUser();
        DatabaseReference reference=FirebaseDatabase.getInstance().getReference("Projects");

        reference.addValueEventListener(new ValueEventListener()
        {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                mProjects.clear();
                for (DataSnapshot snapshot: dataSnapshot.getChildren())
                {
                    Project project=snapshot.getValue(Project.class);

                    if(project.getClient().equals(PresentClientID))
                    {
                        if(project.getStatus().equals(val))
                        {
                            mProjects.add(project);
                        }
                    }
                }

                if(val.equals("NOT_ASSIGNED"))
                {
                    BiddingAdapter =new ClientBiddingAdapter(ClientDashboardActivity.this,mProjects);
                    RV_presentProjects.setAdapter(BiddingAdapter);
                }
                else {
                    Adapter3 =new ClientFinishProjectAdapter(ClientDashboardActivity.this,mProjects);
                    RV_presentProjects.setAdapter(Adapter3);
                }



            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        getMenuInflater().inflate(R.menu.menu,menu);
        return true;
    }


    public boolean onOptionsItemSelected(MenuItem item)
    {
        switch (item.getItemId())
        {
            case R.id.logout:
                FirebaseAuth.getInstance().signOut();
                startActivity(new Intent(ClientDashboardActivity.this, LoginActivity.class));
                finish();
                return true;
        }

        return false;
    }
}
