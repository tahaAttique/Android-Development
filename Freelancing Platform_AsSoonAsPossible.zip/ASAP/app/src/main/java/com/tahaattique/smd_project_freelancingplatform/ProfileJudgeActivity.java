package com.tahaattique.smd_project_freelancingplatform;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.tahaattique.smd_project_freelancingplatform.Adapter.Client_PresentProjects_Adaptor;

import de.hdodenhof.circleimageview.CircleImageView;

public class ProfileJudgeActivity extends AppCompatActivity {

    String username, phoneNo, email1,url, projectname,userID;

    TextView name;
    TextView phone, email, desc;
    CircleImageView img;
    FirebaseUser firebaseUser;
    DatabaseReference reference;
    Button btn_link, btn_assign,chat_btn;
    private RatingBar ratingBar;

    String FreelancerID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_judge);

        name = findViewById(R.id.name);
        phone = findViewById(R.id.phone);
        email = findViewById(R.id.email);
        desc = findViewById(R.id.desc);
        img = findViewById(R.id.img);
        btn_link=findViewById(R.id.openlink);
        btn_assign=findViewById(R.id.assign);
        chat_btn=findViewById(R.id.chat_btn);
        ratingBar = (RatingBar) findViewById(R.id.ratingBar);

        Intent intent = getIntent();
     //   userID=intent.getStringExtra("userid");
        username = intent.getStringExtra("name");
        projectname = intent.getStringExtra("projectname");
        FreelancerID=intent.getStringExtra("FreelancerID");




        /////////////////////////////////////////////////////////////////////////////////////////

        //Farrukh this is the freelancer ID -> FreelancerID
        //Toast.makeText(this, "yo yo " + FreelancerID, Toast.LENGTH_SHORT).show();
////////////////////////////////////////////////////////////////////////////////////////////////////////

        name.setText(username);
        //userID="mE9d1ItTwWMy74lisp7Cllmm8Hq1";
        final FirebaseUser firebaseUser= FirebaseAuth.getInstance().getCurrentUser();
        DatabaseReference reference=FirebaseDatabase.getInstance().getReference("users");

        reference.addValueEventListener(new ValueEventListener()
        {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot snapshot: dataSnapshot.getChildren())
                {
                    User user=snapshot.getValue(User.class);
                    if (user.getUsername().equals(username))
                    {
                      //  name.setText(user.getId());
                        phone.setText(user.getPhone());
                        email.setText(user.getEmail());
                        desc.setText(user.getDesc());
                        url=user.getPortfolio();
                        String sr=user.getRating();
                        Float r=Float.valueOf(user.getRating());
                        ratingBar.setRating(r);
                        ratingBar.setIsIndicator(true);
                        userID=user.getId();
                     //   Toast.makeText(ProfileJudgeActivity.this, userID, Toast.LENGTH_SHORT).show();
                       //Log.i("TAG",userID);
                       // Log.d("MyTag",userID);
                        String encodedImage = user.getImage();


                        byte[] decodedString = Base64.decode(encodedImage, Base64.DEFAULT);
                        Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);

                        img.setImageBitmap(decodedByte);
                    }
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        btn_link.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!url.startsWith("https://") && !url.startsWith("http://")){
                    url = "http://" + url;
                }
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(url));
                startActivity(i);
            }
        });
       chat_btn.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {

               Intent i = new Intent(ProfileJudgeActivity.this,MessageActivity.class);
               i.putExtra("userid",FreelancerID);
               startActivity(i);
           //    Toast.makeText(ProfileJudgeActivity.this, userID, Toast.LENGTH_SHORT).show();

           }
       });
        btn_assign.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                final FirebaseUser firebaseUser= FirebaseAuth.getInstance().getCurrentUser();
                DatabaseReference reference=FirebaseDatabase.getInstance().getReference("Projects");

                reference.addListenerForSingleValueEvent(new ValueEventListener()
                {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        for (DataSnapshot snapshot: dataSnapshot.getChildren())
                        {
                            Project project=snapshot.getValue(Project.class);
                            Log.d("MyTag",projectname);
                            if (project.getName().equals(projectname))
                            {
                                project.setFreelancer(username);
                                project.setStatus("ASSIGNED");
                                snapshot.getRef().setValue(project);
                                finish();
                                break;
                            }

                        }
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
            }
        });

    }
}
