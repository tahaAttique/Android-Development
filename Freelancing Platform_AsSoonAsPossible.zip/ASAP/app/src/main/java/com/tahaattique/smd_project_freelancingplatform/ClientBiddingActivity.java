package com.tahaattique.smd_project_freelancingplatform;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.tahaattique.smd_project_freelancingplatform.Adapter.clistAdapter;

import java.util.ArrayList;
import java.util.List;

public class ClientBiddingActivity extends AppCompatActivity implements clistAdapter.onClickListener {

    Intent intent;
    ArrayList<String> persons;
    ArrayList<String> personsID;
    String ProjectName;
    String FreelancerID1;
    String freelancers;
    FirebaseAuth auth;
    DatabaseReference reference;
    FirebaseUser firebaseUser;
    List<User> mUsers;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_client_bidding);
        persons=new ArrayList<>();
        personsID=new ArrayList<>();
        mUsers=new ArrayList<>();
        auth= FirebaseAuth.getInstance();
        intent=getIntent();
        ProjectName=intent.getStringExtra("getName");
        //FreelancerID=intent.getStringExtra("FreelancerID");

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Applicants");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        RecyclerView clist=findViewById(R.id.clist);
        Button add=findViewById(R.id.add);
        clist.setLayoutManager(new LinearLayoutManager(this));

        clist.setAdapter(new clistAdapter(persons,this));
        readUsers();
        getProj();

    }

    @Override
    public void onClick(int position) {
     //   String userid;
        String name=persons.get(position);
        String nameID=personsID.get(position);
//         User user=mUsers.get(position);

        Intent intent = new Intent(ClientBiddingActivity.this,ProfileJudgeActivity.class);
      //  intent.putExtra("userid",user.getId());
        intent.putExtra("name",name);
        intent.putExtra("projectname",ProjectName);
        intent.putExtra("FreelancerID",nameID);

        startActivity(intent);
    }

    public void getProj( )
    {
        final FirebaseUser firebaseUser= FirebaseAuth.getInstance().getCurrentUser();
        DatabaseReference reference= FirebaseDatabase.getInstance().getReference("Projects");

        reference.addListenerForSingleValueEvent(new ValueEventListener()
        {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                for (DataSnapshot snapshot: dataSnapshot.getChildren())
                {
                    Project project=snapshot.getValue(Project.class);

                    if(project.getName().equals(ProjectName))
                    {
                        freelancers=project.getFreelancer();
                        String[] separated = freelancers.split("~");
                        for(int i = 1; i < separated.length; i++){
                            persons.add(separated[i]);
                        }

                        FreelancerID1=project.getFreelancerID();
                        String[] separated1 = FreelancerID1.split("~");
                        for(int i = 1; i < separated1.length; i++){
                            personsID.add(separated1[i]);
                        }
                        break;
                    }
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
    private void readUsers() {
        final FirebaseUser firebaseUser= FirebaseAuth.getInstance().getCurrentUser();
        DatabaseReference reference=FirebaseDatabase.getInstance().getReference("users");

        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                mUsers.clear();
                for (DataSnapshot snapshot: dataSnapshot.getChildren())
                {
                    User user=snapshot.getValue(User.class);

                    if(!user.getId().equals(firebaseUser.getUid())){
                        mUsers.add(user);
                    }
                }



            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
}
