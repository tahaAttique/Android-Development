package com.tahaattique.smd_project_freelancingplatform;

import java.util.Date;
import java.util.List;

public class Project {
    private String category;
    private String name;
    private String Desc;
    private String requiredDate;
    private String reward;
    private String freelancer;
    private String freelancerID;
    private String client;
    private String attachments;
    private String status;

    public Project() {

    }

    public Project(String category, String name, String desc, String requiredDate, String reward, String freelancer, String freelancerID, String client, String attachments, String status) {
        this.category = category;
        this.name = name;
        Desc = desc;
        this.requiredDate = requiredDate;
        this.reward = reward;
        this.freelancer = "";
        this.freelancerID = "";
        this.client = client;
        this.attachments = attachments;
        this.status = status;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDesc() {
        return Desc;
    }

    public void setDesc(String desc) {
        Desc = desc;
    }

    public String getRequiredDate() {
        return requiredDate;
    }

    public void setRequiredDate(String requiredDate) {
        this.requiredDate = requiredDate;
    }

    public String getReward() {
        return reward;
    }

    public void setReward(String reward) {
        this.reward = reward;
    }

    public String getFreelancer() {
        return freelancer;
    }

    public void setFreelancer(String freelancer) {
        this.freelancer = freelancer;
    }

    public String getFreelancerID() {
        return freelancerID;
    }

    public void setFreelancerID(String freelancerID) {
        this.freelancerID = freelancerID;
    }

    public String getClient() {
        return client;
    }

    public void setClient(String client) {
        this.client = client;
    }

    public String getAttachments() {
        return attachments;
    }

    public void setAttachments(String attachments) {
        this.attachments = attachments;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
