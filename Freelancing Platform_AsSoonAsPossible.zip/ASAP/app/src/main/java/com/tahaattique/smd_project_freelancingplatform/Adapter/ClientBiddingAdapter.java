package com.tahaattique.smd_project_freelancingplatform.Adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.tahaattique.smd_project_freelancingplatform.ClientBiddingActivity;
import com.tahaattique.smd_project_freelancingplatform.FreelancerBiddingScreen;
import com.tahaattique.smd_project_freelancingplatform.Project;
import com.tahaattique.smd_project_freelancingplatform.ProjectDetailActivity;
import com.tahaattique.smd_project_freelancingplatform.R;

import java.util.List;

public class ClientBiddingAdapter extends RecyclerView.Adapter<ClientBiddingAdapter.ViewHolder>{

    private Context mContext;
    private List<Project> projects;

    public ClientBiddingAdapter() {
    }

    public ClientBiddingAdapter(Context mContext, List<Project> projects) {
        this.mContext = mContext;
        this.projects = projects;
    }

    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.project_item,parent,false);  // changes required
        return new ClientBiddingAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position)
    {
        final Project project=projects.get(position);
        holder.txt_name.setText(project.getName());
        holder.txt_requiredDate.setText(project.getRequiredDate());
        holder.txt_reward.setText(project.getReward());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(mContext, ClientBiddingActivity.class);
                intent.putExtra("getCategory",project.getCategory());
                intent.putExtra("getName",project.getName());
                intent.putExtra("getDesc",project.getDesc());
                intent.putExtra("getRequiredDate",project.getRequiredDate());
                intent.putExtra("getReward",project.getReward());
                intent.putExtra("getFreelancer",project.getFreelancer());
                intent.putExtra("getClient",project.getClient());
                intent.putExtra("attachments",project.getAttachments());
                intent.putExtra("status",project.getStatus());
                intent.putExtra("FreelancerID",project.getFreelancerID());
                mContext.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return projects.size();
    }


    public class ViewHolder extends RecyclerView.ViewHolder {

        public TextView txt_category,txt_name,
                txt_requiredDate,txt_reward,txt_freelancer,txt_client,txt_status,
                category,name1,requiredDate,reward,freelancer,client,status;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            requiredDate=itemView.findViewById(R.id.requiredDate);
            reward=itemView.findViewById(R.id.reward);

            txt_name=itemView.findViewById(R.id.txt_name);
            txt_requiredDate=itemView.findViewById(R.id.txt_requiredDate);
            txt_reward=itemView.findViewById(R.id.txt_reward);
        }
    }
}
