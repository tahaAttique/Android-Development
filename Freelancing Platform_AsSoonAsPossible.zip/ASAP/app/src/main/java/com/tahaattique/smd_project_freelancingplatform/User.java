package com.tahaattique.smd_project_freelancingplatform;

public class User {
    private String id;
    private String username;
    private String phone;
    private String status;
    private String email;
    private String image;
    private String portfolio;
    private String desc;
    private String rating;

    public User(String id, String username, String phone, String status, String email, String image, String portfolio, String desc, String rating) {
        this.id = id;
        this.username = username;
        this.phone = phone;
        this.status = status;
        this.email = email;
        this.image = image;
        this.portfolio = portfolio;
        this.desc = desc;
        this.rating=rating;
    }

    public User() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setRating(String rating) {
        this.rating = rating;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getStatus() {
        return status;
    }

    public String getEmail() {
        return email;
    }

    public String getImage() {
        return image;
    }

    public String getPortfolio() {
        return portfolio;
    }

    public String getDesc() {
        return desc;
    }

    public String getRating() {
        return rating;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
